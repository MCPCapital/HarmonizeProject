var Arbitrage = require('./build/contracts/Arbitrage.json')

module.exports = {
  Arbitrage: Arbitrage
}
